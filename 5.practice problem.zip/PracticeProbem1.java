package Testing.Practice_phase5_project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeProbem1 {

    WebDriver driver;

    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    
        driver.quit();
    }

}
