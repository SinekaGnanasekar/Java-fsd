package Testing.Practice_phase5_project;

import org.testng.annotations.BeforeMethod;
import java.io.File;
import java.util.logging.FileHandler;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Practiceproblem5 {

    WebDriver driver;

    @BeforeMethod
	public void setUp() {
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        File screenshotFile =((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
        File dest= new File("./snaps/screenshot.png");
        FileHandler.copy(screenshotFile, dest);
    
    }
    }
