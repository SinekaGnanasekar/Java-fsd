package linkedlist;
	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class LinkedList {
	    Node head;

	    void deleteFirstOccurrence(int key) {
	        Node current = head;
	        Node prev = null;

	       
	        if (current != null && current.data == key) {
	            head = current.next;
	            return;
	        }

	        
	        while (current != null && current.data != key) {
	            prev = current;
	            current = current.next;
	        }

	        
	        if (current == null) {
	            System.out.println("Key not found in the list.");
	            return;
	        }

	    
	        prev.next = current.next;
	    }

	    void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }
	}

	public class LinkedlistDemo {
	    public static void main(String[] args) {
	        LinkedList list = new LinkedList();
	        list.head = new Node(4);
	        list.head.next = new Node(8);

	        System.out.println("Original linked list:");
	        list.display();

	        int keyToDelete = 4;
	        list.deleteFirstOccurrence(keyToDelete);

	        System.out.println("Linked list after deleting " + keyToDelete + ":");
	        list.display();
	    }
	}

