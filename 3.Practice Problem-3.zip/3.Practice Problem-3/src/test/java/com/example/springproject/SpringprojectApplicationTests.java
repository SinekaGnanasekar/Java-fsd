package com.example.springproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
