package com.example.springproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public com.example.springproject.User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Transactional
    public com.example.springproject.User updateUser(com.example.springproject.User user) {
        return userRepository.save(user);
    }
}
