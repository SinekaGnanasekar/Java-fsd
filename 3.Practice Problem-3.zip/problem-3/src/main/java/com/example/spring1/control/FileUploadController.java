package com.example.spring1.control;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class FileUploadController {
    private final String uploadDirectory = "/path/to/your/upload/directory";

    
    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        try {
            
            if (!file.isEmpty()) {
              
                String originalFilename = file.getOriginalFilename();
               
                Path filePath = Paths.get(uploadDirectory, originalFilename);

            
                Files.write(filePath, file.getBytes());

            
                redirectAttributes.addFlashAttribute("message", "File uploaded successfully!");
            }
        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("message", "File upload failed.");
        }

        return "redirect:/";
    }
}

