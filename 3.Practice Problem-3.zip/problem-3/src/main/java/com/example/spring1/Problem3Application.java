package com.example.spring1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Problem3Application {

	public static void main(String[] args) {
		SpringApplication.run(Problem3Application.class, args);
	}

}
