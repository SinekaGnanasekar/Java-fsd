package com.example.spring1.service;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
public class FileDownloadController {
    private final String uploadDirectory = "/path/to/your/upload/directory";

    
    @GetMapping("/download/{filename}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String filename) {
        try {
           
            Path filePath = Paths.get(uploadDirectory, filename);

         
            if (Files.exists(filePath)) {
               
                Resource fileResource = new FileSystemResource(filePath.toFile());
                return ResponseEntity.ok()
                        .body(fileResource);
            } else {
               
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
         
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
