package com.example.spring1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Problem3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
