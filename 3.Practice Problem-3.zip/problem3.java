package junit.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

public class problem3 {
    @Test
    @EnabledIfSystemProperty(named = "os.name", matches = "Windows")
    void testOnWindows() {
        System.out.println("Running on Windows");
    }
}
