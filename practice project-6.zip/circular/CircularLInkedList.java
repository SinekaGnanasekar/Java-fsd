package circular;

	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

  public class CircularLInkedList {
	    Node head;

	    void insertSorted(int newData) {
	        Node newNode = new Node(newData);

	        if (head == null) {
	           
	            head = newNode;
	            newNode.next = newNode; 
	            return;
	        }

	        Node current = head;

	        
	        while (current.next != head && current.next.data < newData) {
	            current = current.next;
	        }

	       
	        newNode.next = current.next;
	        current.next = newNode;
	    }

	    void display() {
	        Node current = head;
	        if (head != null) {
	            do {
	                System.out.print(current.data + " ");
	                current = current.next;
	            } while (current != head);
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        CircularLInkedList list = new CircularLInkedList();
	        list.insertSorted(5);
	        list.insertSorted(7);
	        list.insertSorted(6);
	        list.insertSorted(8);

	        System.out.println("Sorted Circular Linked List:");
	        list.display();
	    }
  }
