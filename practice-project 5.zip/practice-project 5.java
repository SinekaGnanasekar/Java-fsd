package customexpection;

class CustomException extends Exception {
	    public CustomException(String message) {
	        super(message);
	    }
	}

	public class CUSTOMEXPECTION {
	    public static void main(String[] args) {
	        try {
	            performOperation();
	        } catch (CustomException e) {
	            System.err.println("Custom Exception caught: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }

	    public static void performOperation() throws CustomException {
	        try {
	            int result = divide(10, 0); // This will throw an ArithmeticException
	        } catch (ArithmeticException e) {
	            throw new CustomException("CustomException: Division by zero is not allowed.");
	        }
	    }

	    public static int divide(int num, int deno) {
	        return num / deno;
	    }
	}

