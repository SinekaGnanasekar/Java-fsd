package com.example.springprogram.controller;


public class Authentication {
    public boolean authenticateUser(String username, String password) {
        if ("validUsername".equals(username) && "validPassword".equals(password)) {
            return true; 
        }
        return false; 
    }
}
