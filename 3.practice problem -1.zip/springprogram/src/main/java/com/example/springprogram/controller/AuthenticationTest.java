package com.example.springprogram.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.Test;

public class AuthenticationTest {

    @Test
    public void testSuccessfulAuthentication() {
        Authentication auth = new Authentication();
        boolean result = auth.authenticateUser("validUsername", "validPassword");
        assertTrue(result, "Authentication should succeed with valid credentials.");
    }

    @Test
    public void testFailedAuthentication() {
        Authentication auth = new Authentication();
        boolean result = auth.authenticateUser("invalidUsername", "invalidPassword");
        assertFalse(result, "Authentication should fail with invalid credentials.");
    }

}
