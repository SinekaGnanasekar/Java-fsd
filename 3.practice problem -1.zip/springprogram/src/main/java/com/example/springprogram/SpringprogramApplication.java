package com.example.springprogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringprogramApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringprogramApplication.class, args);
	}

}
