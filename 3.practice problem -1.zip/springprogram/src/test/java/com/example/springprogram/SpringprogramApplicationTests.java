package com.example.springprogram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringprogramApplicationTests {

	@Test
	void contextLoads() {
	}

}
