package com.program.spring.first;

public class firstprogram {

}
