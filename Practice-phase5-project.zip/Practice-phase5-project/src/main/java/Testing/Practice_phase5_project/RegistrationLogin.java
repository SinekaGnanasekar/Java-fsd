package Testing.Practice_phase5_project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegistrationLogin {

    WebDriver driver;

    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    public void registerUser() {
        driver.get("https://www.facebook.com/");

        WebElement usernameInput = driver.findElement(By.id("email"));
        WebElement passwordInput = driver.findElement(By.id("pass"));
        WebElement submitButton = driver.findElement(By.name("login"));

        usernameInput.sendKeys("abc@gmail.com");
        passwordInput.sendKeys("12345@");
        submitButton.click();

       
    }

    public void loginUser() {
        driver.get("https://www.facebook.com/");

        WebElement usernameInput = driver.findElement(By.id("email"));
        WebElement passwordInput = driver.findElement(By.id("pass"));
        WebElement submitButton = driver.findElement(By.name("login"));

        usernameInput.sendKeys("abc@gmail.com");
        passwordInput.sendKeys("12345@");
        submitButton.click();

        
    }

    public void tearDown() {
        driver.quit();
    }

    public static void main(String[] args) {
        RegistrationLogin registrationLogin = new RegistrationLogin();
        registrationLogin.setUp();
        registrationLogin.registerUser();
        registrationLogin.loginUser();
        registrationLogin.tearDown();
    }
}
