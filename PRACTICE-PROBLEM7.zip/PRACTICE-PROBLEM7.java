package innerclass;

public class Outer {
	    private int outerVar = 80;

	    // Inner class definition
	    public class Inner {
	        private int innerVar = 90;

	        public void displayInner() {
	            System.out.println("Inner class variable: " + innerVar);
	            System.out.println("Outer class variable from Inner class: " + outerVar);
	        }
	    }

	    public void displayOuter() {
	        System.out.println("Outer class variable: " + outerVar);
	    }

	    public static void main(String[] args) {
	        Outer outerObj = new Outer();
	        Outer.Inner innerObj = outerObj.new Inner();
	        innerObj.displayInner();
	        outerObj.displayOuter();
	    }
	}

