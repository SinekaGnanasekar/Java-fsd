package junit.test;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestReporter;
import org.junit.jupiter.api.Nested;

public class problem4 {

    @Test
    void simpleTest() {
        System.out.println("Simple Test");
    }

    @RepeatedTest(3)
    void repeatedTest(RepetitionInfo repetitionInfo) {
        int currentRepetition = repetitionInfo.getCurrentRepetition();
        System.out.println("Repeated Test " + currentRepetition);
    }

    @Nested
    class NestedTests {

        @Test
        void nestedTest1() {
           
            System.out.println("Nested Test 1");
        }

        @Test
        void nestedTest2() {
         
            System.out.println("Nested Test 2");
        }
    }
}
