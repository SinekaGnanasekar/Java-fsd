package exceptionhandling;

public class EXCEPTION {
	    public static void main(String[] args) {
	        try {
	            int result = divide(10, 0);     //  divide by zero
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	                         // Catching and handling
	            System.err.println("Error: Division by zero is not allowed.");
	        }

	                       // Code continues to execute 
	        System.out.println("Program continues...");
	    }
	    public static int divide(int num, int deno) {
	        return num / deno;
	    }
	}
