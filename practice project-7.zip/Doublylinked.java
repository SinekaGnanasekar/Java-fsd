package traverse;

	class Node {
	    int data;
	    Node next;
	    Node prev;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	        this.prev = null;
	    }
	}

	 public class Doublylinked {
	    Node head;

	    void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	            newNode.prev = current;
	        }
	    }

	    void traverseForward() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    void traverseBackward() {
	        Node current = head;
	        while (current != null && current.next != null) {
	            current = current.next;
	        }
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.prev;
	        }
	        System.out.println();
	    }
	
	    public static void main(String[] args) {
	        Doublylinked list = new Doublylinked();
	        list.insert(7);
	        list.insert(8);
	        list.insert(3);

	        System.out.println("Forward traversal:");
	        list.traverseForward();

	        System.out.println("Backward traversal:");
	        list.traverseBackward();
	    }
	}
