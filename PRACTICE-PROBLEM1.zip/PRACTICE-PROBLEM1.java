package first;

public class PRACTICEPROBLEM1 {

	    public static void main(String[] args) {
	        
	        int a= 92;
	        double b = (double) a; // Implicit casting

	        System.out.println("Implicit Casting" + b);
	     

	   
	        double c = 88.66;
	        int d = (int) c; // Explicit casting

	        System.out.println("\nExplicit Casting "+ d);
	    }
	}


