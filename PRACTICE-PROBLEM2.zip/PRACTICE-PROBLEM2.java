package ACCESS;

	class MyClass {
	                        // Public method 
	    public void publicMethod() {
	        System.out.println("This is a public method.");
	    }
	                        // Default method 
	    void defaultMethod() {
	        System.out.println("This is a default method.");
	    }

	                      // Private method
	    private void privateMethod() {
	        System.out.println("This is a private method.");
	    }

	             // Protected method 
	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }
	}

	public class ACCESSSPECIFIERS {
	    public static void main(String[] args) {
	        MyClass obj = new MyClass();
	        obj.publicMethod();
	        obj.defaultMethod();
	  // obj.privateMethod(); //  compile-time error
	        obj.protectedMethod();

	    }
	}
