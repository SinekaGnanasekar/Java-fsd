package constructors;


class MyCls {
    private int num;
    private String text;

                                 // Default Constructor
    public MyCls() {
        num = 0;
        text = "Default";
    }

                                       // Parameterized Constructor
    public MyCls(int num, String text) {
        this.num = num;
        this.text = text;
    }

                                   // Overloaded Constructor
    public  MyCls (int num) {
        this.num = num;
        this.text = "Overloaded";
    }

    public void display() {
        System.out.println("Number: " + num);
        System.out.println("Text: " + text);
    }
}

public class PRACTICEPROBLEM2{
    public static void main(String[] args) {
        
        MyCls Obj = new MyCls();
        MyCls Obj1 = new MyCls(42, "Parameterized");
       MyCls Obj2 = new MyCls(10);

      
        System.out.println("Default Constructor:");
        Obj.display();

        System.out.println("\nParameterized Constructor:");
        Obj1.display();

        System.out.println("\nOverloaded Constructor:");
        Obj2.display();
    }
}



