package junit.test;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

public class problem5 {

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
            dynamicTest("Test 1", () -> assertEquals(2, 1 + 1)),
            dynamicTest("Test 2", () -> assertEquals(4, 2 * 2)),
            dynamicTest("Test 3", () -> assertEquals(6, 3 * 2))
        );
    }

    @TestFactory
    Collection<DynamicTest> dynamicTestsFromData() {
        Collection<String> data = Arrays.asList("apple", "banana", "cherry");

        return data.stream().map(item -> dynamicTest("Test " + item, () -> {
            assertEquals(5, item.length());
        })).toList();
    }
}
