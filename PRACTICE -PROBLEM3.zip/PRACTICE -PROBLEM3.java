package method;

public class METHODS {
	    public static void main(String[] args) {
	    	      
	    	         METHODS verifier = new METHODS();
	    	         
	    	        int sum = verifier.add(10, 20);
	    	        System.out.println("The sum of 10 and 20 is: " + sum);

	    	       
	    	        int difference = verifier.subtract(20, 10);
	    	        System.out.println("The difference of 20 and 10 is: " + difference);

	    	        
	    	        int product = verifier.multiply(10, 20);
	    	        System.out.println("The product of 10 and 20 is: " + product);

	    	        
	    	        int quotient = verifier.divide(20, 10);
	    	        System.out.println("The quotient of 20 and 10 is: " + quotient);
	    	        
	    	        verifier.callStaticMethod();
	    	        verifier.callInstanceMethod();
	    	    }

	    	 
	    	    public int add(int a, int b) {
	    	        return a + b;
	    	    }

	    	   
	    	    public int subtract(int a, int b) {
	    	        return a - b;
	    	    }

	    	
	    	    public int multiply(int a, int b) {
	    	        return a * b;
	    	    }

	    	  
	    	    public int divide(int a, int b) {
	    	        return a / b;
	    	    }

	    	  
	    	    public static void callStaticMethod() {
	    	        System.out.println("This is a static method");
	    	    }


	    	    public void callInstanceMethod() {
	    	        System.out.println("This is an instance method");
	    	    }

	    	    
	    	    public void callMethodUsingObject(METHODS verifier) {
	    	        verifier.callInstanceMethod();
	    	    }
}
