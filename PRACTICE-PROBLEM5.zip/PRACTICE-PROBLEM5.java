package collections;

import java.util.ArrayList;
import java.util.HashSet;


public class collections {
    public static void main(String[] args) {
                                              // arrayList
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("orange");
        arrayList.add("grapes");

        System.out.println("ArrayList Example:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

                                                 // HashSet Example
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(90);
        hashSet.add(60);

        System.out.println("\nHashSet Example:");
        for (int number : hashSet) {
            System.out.println(number);
        }

        
    }
}

