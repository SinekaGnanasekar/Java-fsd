package com.example.spring1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.spring1.demo.Post;

@Service
public class PostService {
    private final String BASE_URL = "https://jsonplaceholder.typicode.com";
    private final RestTemplate restTemplate;

    @Autowired
    public PostService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Post getPostById(Long postId) {
        return restTemplate.getForObject(BASE_URL + "/posts/" + postId, Post.class);
    }
}
