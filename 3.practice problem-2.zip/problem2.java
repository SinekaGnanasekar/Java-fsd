package junit.test;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

public class problem2 {

    @Test
    void testEquality() {
        assertEquals(4, 2 + 2);
    }

    @Test
    void testInequality() {
        assertNotEquals(7, 3 * 2);
    }

    @Test
    void testTrue() {
        assertTrue(5 > 3);
    }

    @Test
    void testFalse() {
        assertFalse(4 < 2);
    }

    @Test
    void testNull() {
        assertNull(null);
    }

    @Test
    void testNotNull() {
        assertNotNull("Hello");
    }

    @Test
    void testArrayEquality() {
        assertArrayEquals(new int[]{1, 2, 3}, new int[]{1, 2, 3});
    }

    @Test
    void testStringEqualityIgnoringCase() {
        assertEquals("JUnit", "junit", String.CASE_INSENSITIVE_ORDER);
    }
}
