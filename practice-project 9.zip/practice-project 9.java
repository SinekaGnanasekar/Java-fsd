package diamond;

	interface Animal {
	    void sound();
	}


	class Dog implements Animal {
	    @Override
	    public void sound() {
	        System.out.println("Dog barks.");
	    }
	}

	class Cat implements Animal {
	    @Override
	    public void sound() {
	        System.out.println("Cat meows.");
	    }
	}

	
	class Pet implements Animal {
	    private Animal pet;

	    public Pet(String type) {
	        if (type.equalsIgnoreCase("Dog")) {
	            pet = new Dog();
	        } else if (type.equalsIgnoreCase("Cat")) {
	            pet = new Cat();
	        }
	    }

	    
	    @Override
	    public void sound() {
	        pet.sound();
	    }
	}

	public class DIAMOND {
	    public static void main(String[] args) {
	        Pet myPet = new Pet("Dog");
	        myPet.sound(); 

	        Pet anotherPet = new Pet("Cat");
	        anotherPet.sound(); 
	    }
	}


