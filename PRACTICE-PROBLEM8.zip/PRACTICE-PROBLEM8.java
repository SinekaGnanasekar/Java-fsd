package STRING;

public class STRING {

	    public static void main(String[] args) {
	 
	        String str = "Hello World";

	                           // StringBuffer
	        StringBuffer Buffer = new StringBuffer(str);

	                           //  StringBuilder
	        StringBuilder Builder = new StringBuilder(str);

	       
	        System.out.println("Original String: " + str);
	        System.out.println("StringBuffer: " + Buffer.toString());
	        System.out.println("StringBuilder: " + Builder.toString());
	    }
	}
