package fileoperation;

import java.io.*;

public class FILEOPERATIONS {
	    public static void main(String[] args) {
	        String filePath = "file.txt";
	        
	        createFile(filePath);

	     
	        writeToFile(filePath, "Hello, World!");
	        
	        String fileContents = readFile(filePath);
	        System.out.println("File Contents: " + fileContents);

	      
	        updateFile(filePath, "Updated content!");

	       
	        fileContents = readFile(filePath);
	        System.out.println("Updated File Contents: " + fileContents);

	        
	        deleteFile(filePath);
	    }

	    // Create a new file
	    public static void createFile(String filePath) {
	        try {
	            File file = new File(filePath);
	            if (file.createNewFile()) {
	                System.out.println("File created: " + filePath);
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.err.println("Error creating file: " + e.getMessage());
	        }
	    }

	                 // Write content to the file
	    public static void writeToFile(String filePath, String content) {
	        try (FileWriter writer = new FileWriter(filePath)) {
	            writer.write(content);
	            System.out.println("Content written to the file.");
	        } catch (IOException e) {
	            System.err.println("Error writing to the file: " + e.getMessage());
	        }
	    }

	               // Read content from the file
	    public static String readFile(String filePath) {
	        StringBuilder content = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line).append("\n");
	            }
	        } catch (IOException e) {
	            System.err.println("Error reading from the file: " + e.getMessage());
	        }
	        return content.toString();
	    }

	              // Update content of the file
	    public static void updateFile(String filePath, String updatedContent) {
	        writeToFile(filePath, updatedContent);
	        System.out.println("File updated.");
	    }

	                          // Delete the file
	    public static void deleteFile(String filePath) {
	        File file = new File(filePath);
	        if (file.delete()) {
	            System.out.println("File deleted: " + filePath);
	        } else {
	            System.err.println("Failed to delete the file.");
	        }
	    }
	}
  
