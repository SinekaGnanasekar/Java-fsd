package threads;

	class MyThread extends Thread {
	    public void run() {
	        for (int i = 1; i <= 3; i++) {
	            System.out.println("Thread extending Thread class: " + i);
	            try {
	                Thread.sleep(1000); // Sleep for 1 second
	            } catch (InterruptedException e) {
	                System.out.println(e);
	            }
	        }
	    }
	}

	class MyRunnable implements Runnable {
	    public void run() {
	        for (int i = 1; i <= 2; i++) {
	            System.out.println("Thread implementing Runnable interface: " + i);
	            try {
	                Thread.sleep(500); // Sleep for 1 second
	            } catch (InterruptedException e) {
	                System.out.println(e);
	            }
	        }
	    }
	}

	public class MYTHREADS{
	    public static void main(String[] args) {
	        MyThread thread1 = new MyThread();
	        Thread thread2 = new Thread(new MyRunnable());

	        thread1.start();
	        thread2.start();
	    }
	}

