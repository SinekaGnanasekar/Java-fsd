package oops;


	class Car {
	    String brand;
	    String model;
	    int year;
	    
	    // Constructor 
	    public Car(String brand, String model, int year) {
	        this.brand = brand;
	        this.model = model;
	        this.year = year;
	    }
	    
	    // Method 
	    public void displayInfo() {
	        System.out.println("Car: " + brand + " " + model + " (" + year + ")");
	    }
	}

	// inheritance
	class SportsCar extends Car {
	    // Additional attribute
	    boolean isConvertible;
	    
	    // Constructor for SportsCar
	    public SportsCar(String brand, String model, int year, boolean isConvertible) {
	        super(brand, model, year);
	        this.isConvertible = isConvertible;
	    }
	    
	    // Override 
	    @Override
	    public void displayInfo() {
	        super.displayInfo(); // Call the parent class method
	        if (isConvertible) {
	            System.out.println("This is a convertible sports car.");
	        } else {
	            System.out.println("This is a sports car.");
	        }
	    }
	}

	public class OOPSCONCEPT{
	    public static void main(String[] args) {
	      
	        Car sedan = new Car("Toyota", "Camry", 2022);
	        SportsCar sportsCar = new SportsCar("Porsche", "911", 2023, true);
	        
	        System.out.println("Car brand: " + sedan.brand);
	        
	        sedan.displayInfo(); // Calls the Car class method
	        sportsCar.displayInfo(); // Calls the SportsCar class method
	       
	    }
	}

