package EXPERSSION;

		import java.util.regex.Pattern;
		import java.util.regex.Matcher;

		public class PRACTICEPROBLEM10{

		    public static void main(String[] args) {
		        String regex = "^\\d{3}-\\d{3}-\\d{4}$";
		        String text = "123-456-7890";

		        Pattern pattern = Pattern.compile(regex);
		        Matcher matcher = pattern.matcher(text);

		        if (matcher.matches()) {
		            System.out.println("The text matches the regular expression.");
		        } else {
		            System.out.println("The text does not match the regular expression.");
		        }
		    }
		}

