package queue;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDEMO {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue (add)
        queue.offer(1);
        queue.offer(2);
        queue.offer(3);

        System.out.println("Queue: " + queue);

        // Dequeue (remove) 
        int removedElement = queue.poll();
        System.out.println("Removed Element: " + removedElement);
        System.out.println("Queue  " + queue);
    }
}
