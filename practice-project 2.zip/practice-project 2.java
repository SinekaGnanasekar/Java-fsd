package sleep;


	class SleepThread extends Thread {
	    @Override
	    public void run() {
	        for (int i = 1; i <= 3; i++) {
	            System.out.println("SleepThread: Count " + i);
	            try {
	                Thread.sleep(500);
	            } catch (InterruptedException e) {
	                System.err.println("SleepThread interrupted: " + e.getMessage());
	            }
	        }
	    }
	}

	class WaitThread extends Thread {
	    private final Object lock;

	    public WaitThread(Object lock) {
	        this.lock = lock;
	    }

	    @Override
	    public void run() {
	        synchronized (lock) {
	            System.out.println("WaitThread: Waiting for notification...");
	            try {
	                lock.wait();
	            } catch (InterruptedException e) {
	                System.err.println("WaitThread interrupted: " + e.getMessage());
	            }
	            System.out.println("WaitThread: Resumed after notification.");
	        }
	    }
	}

	public class SLEEP {
	    public static void main(String[] args) {
	        Object lock = new Object();

	        SleepThread sleepThread = new SleepThread();
	        WaitThread waitThread = new WaitThread(lock);

	        sleepThread.start();
	        waitThread.start();

	        try {
	            Thread.sleep(300);
	        } catch (InterruptedException e) {
	            System.err.println("Main thread interrupted: " + e.getMessage());
	        }

	        synchronized (lock) {
	            System.out.println("Main Thread: Notifying waiting thread...");
	            lock.notify();
	        }
	    }
	}
