package ARRAYS;

public class ARRAYS {
	public static void main(String[] args) {
		
        int[] numbers = {1,2,3,4,5,6,7};
        
        System.out.println("All elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }
    }
}