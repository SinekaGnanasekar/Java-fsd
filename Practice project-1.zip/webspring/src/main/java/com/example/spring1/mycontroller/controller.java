package com.example.spring1.mycontroller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring1.controller.MyCustomException;

@RestController
public class controller {

    private boolean someConditionIsMet;

	@GetMapping("/example")
    public ResponseEntity<String> example() {
        if (someConditionIsMet) {
            throw new MyCustomException("Custom error message");
        } else {
            return ResponseEntity.ok("Success");
        }
    }
}
